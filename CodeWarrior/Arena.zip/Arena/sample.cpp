#include <bits/stdc++.h>

#define GREENTEAM 1
#define BLUETEAM 2

// Input constants
#define BLOCKED -1
#define EMPTY 0
#define G_FRONTLINER 1
#define G_DESTROYER 2
#define G_BASE 3
#define B_FRONTLINER 4
#define B_DESTROYER 5
#define B_BASE 6

#define ROWS 16
#define COLS 12

// Type of moves
#define PLAIN 0
#define SACRIFICE 1

using namespace std;

bool isValidMove(int myPlayer, int board[ROWS][COLS], int myMovesLeft[ROWS][COLS], int oppMovesLeft[ROWS][COLS], int xi, int yi, int xj, int yj)
{
    return true;
}

int main()
{
    int myPlayer;
    int board[ROWS][COLS];
    int myMovesLeft[ROWS][COLS];
    int oppMovesLeft[ROWS][COLS];

    cin >> myPlayer;

    for (int i = 0; i < ROWS; i++)
    {
        for (int j = 0; j < COLS; j++)
        {
            cin >> board[i][j];
        }
    }

    for (int i = 0; i < ROWS; i++)
    {
        for (int j = 0; j < COLS; j++)
        {
            cin >> myMovesLeft[i][j];
        }
    }

    for (int i = 0; i < ROWS; i++)
    {
        for (int j = 0; j < COLS; j++)
        {
            cin >> oppMovesLeft[i][j];
        }
    }

    int myMoveType = PLAIN;
    int xi = 5, yi = 2, xj = 6, yj = 2;
    if (myPlayer == GREENTEAM) 
    {
        xi = 5; yi = 2; xj = 6; yj = 2;
    }
    else 
    {
        xi = 10; yi = 2; xj = 9; yj = 2;
    }

    if (myMoveType == PLAIN && isValidMove(myPlayer, board, myMovesLeft, oppMovesLeft, xi, yi, xj, yj))
    {
        cout << myMoveType << endl;
        cout << xi << endl;
        cout << yi << endl;
        cout << xj << endl;
        cout << yj << endl;
    }
    else if (myMoveType == SACRIFICE && isValidMove(myPlayer, board, myMovesLeft, oppMovesLeft, xi, yi, xj, yj))
    {
        cout << myMoveType << endl;
        cout << xi << endl;
        cout << yi << endl;
    }
    else
    {
        //not possible
        cout << 0 << endl;
        cout << -1 << endl;
        cout << -1 << endl;
        cout << -1 << endl;
        cout << -1 << endl;
    }

    return 0;
}
